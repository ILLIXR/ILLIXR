var searchData=
[
  ['register_5fimpl_35',['register_impl',['../classILLIXR_1_1phonebook.html#a762bdfd2ddad1f23c2ff3816c0ea0a85',1,'ILLIXR::phonebook']]],
  ['reliable_5fsleep_36',['reliable_sleep',['../classILLIXR_1_1threadloop.html#a3d3af8e7e70c0be2eb1864a245e2570d',1,'ILLIXR::threadloop']]]
];
