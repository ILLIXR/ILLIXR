var searchData=
[
  ['design_5fdecisions_2',['design_decisions',['../md_design_decisions.html',1,'']]]
];
