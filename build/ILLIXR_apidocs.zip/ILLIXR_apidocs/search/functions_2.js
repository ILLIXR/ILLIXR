var searchData=
[
  ['get_5flatest_30',['get_latest',['../classILLIXR_1_1reader__latest.html#a75cf9ef72176d9b5e389f382fb222c3b',1,'ILLIXR::reader_latest']]],
  ['get_5flatest_5fro_31',['get_latest_ro',['../classILLIXR_1_1reader__latest.html#ae15fef660962392d94c34696e99dd803',1,'ILLIXR::reader_latest']]]
];
